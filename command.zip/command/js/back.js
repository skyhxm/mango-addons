define(["jquery", "easy-admin","okLayer", "iconPickerFa", "autocomplete"], function($, ea,okLayer) {
    var form = layui.form,
        iconPickerFa = layui.iconPickerFa,
        autocomplete = layui.autocomplete,
        i = 0;
        ii = 0;

    //==========================一键curd===============================//
    //初始化主表
    var main_table = $('.main-table').val()
    setFields('.field-data', main_table)
    //设置字段信息
    function setFields(el, table_name) {
        // console.log(el,table_name)
        if (table_name) {
            $.get('getFields', {
                    'table_name': table_name
                },
                function(data) {
                    var main_key = $(el).parent().prev().hasClass('main-key')
                    if (main_key) {
                        $(el).parent().prev().find('option').remove();
                        for (var i in data) {
                            $(el).parent().prev().find('select').append('<option value="' + data[i]['name'] + '">' + data[i]['name'] + '</option>');
                        }
                    }
                    var other_key = $(el).parent().prev().prev().hasClass('other-key')
                    if (other_key) {
                        $(el).parent().prev().prev().find('option').remove();
                        for (var i in data) {
                            $(el).parent().prev().prev().find('select').append('<option value="' + data[i]['name'] + '">' + data[i]['name'] + '</option>');
                        }
                    }
                    console.log(main_key, other_key)
                    //渲染多选
                    var demo2 = xmSelect.render({
                        el: el,
                        data: data,
                        on: function(data) {
                            //arr:  当前多选已选中的数据
                            var arr = data.arr;
                            let r = arr.map(item => {
                                return item.name;
                            }).join(',').split(',');
                            $(el).prev().val(r)
                        },
                    })

                    form.render()
                }
            );
        }
    }
    // 点击追加关联模型
    $('#add-content').click(function() {
        i++
        // 添加类名
        $('#tpl').find('.field-data').addClass('field-data' + i)
        $('#tpl').find('.other-table').addClass('other-table' + i)
        //修改name
        $('#tpl').find('.other-table').prop('name','otable'+i)
        $('#tpl').find('.other-type').prop('name','otype'+i)
        $('#tpl').find('.other-key select').prop('name','okey'+i)
        $('#tpl').find('.main-key select').prop('name','mkey'+i)
        $('#tpl').find('.fields-div input').prop('name','ofields'+i)
        $('input[name="numbers"]').val(i)
        $('#add-temptl').append(
            $('#tpl').html()
        )
        var table_name = $('.other-table' + i).val()
        setFields('.field-data' + i, table_name)

    })
    //选择主表
    form.on('select(main-table)', function(data) {
        var classes = data.elem.getAttribute("class")
        if (classes) {
            var arr = classes.split(/[ ]+/); //以空格分开
            var lenth = (arr.length)
            var table_class = '.' + arr[lenth - 1];
        }
        console.log(table_class)
        var class_fields = $(table_class).parent().parent().find('.fields-div').find('.demo').attr('class')
        if (class_fields) {
            var arr = class_fields.split(/[ ]+/); //以空格分开
            var lenth = (arr.length)
            var table_class = '.' + arr[lenth - 1];
        }
        $(this).val('');
        setFields(table_class, data.value)
    })
    // 点击移除
    $(document).on('click', '.del-btn', function() {
        //去除数量
        var n = $('input[name="numbers"]').val()
        $('input[name="numbers"]').val(n-1)
        $(this).parent().parent().parent().remove()
    })
    // 显示关联按钮
    form.on('checkbox(showmodel)', function(data) {
        if (data.elem.checked) { //判断当前多选框是选中还是取消选中
            $('#table-set').show()
        } else {
            $('#table-set').hide()
        }
    });
    // 生成命令行
    $('#create_cmd').click(function(){
        $('input[name="cmd"]').val(1)
        $.get('add', 
               $("#curd_form").serializeArray()
            ,
            function(data) {
                $('input[name="create_cmd"]').val(data)
            }
        );
    })
    // 立即执行
    $('#create').click(function(){
        layer.confirm('确定执行吗？？', {
          btn: ['确定', '取消'] //可以无限个按钮
        }, function(index, layero){
            $('input[name="cmd"]').val(0)
            $.get('add', 
                   $("#curd_form").serializeArray()
                ,
                function(data) {
                    data.data = data.data+'&#10;'
                    data.data += $('#res_msg').html()
                    $('#res_msg').html(data.data)
                    form.render()
                }
            );
            layer.close(index)
        });
    })
    //=============================生成菜单==========================//
    // 生成菜单命令行
    $('#create_cmd_menu').click(function(){
        $('input[name="cmd"]').val(1)
        $.get('add', 
               $("#menu_form").serializeArray()
            ,
            function(data) {
                $('input[name="create_cmd_menu"]').val(data)
            }
        );
    })
    // 立即执行
    $('#create_menu').click(function(){
        layer.confirm('确定执行吗？？', {
          btn: ['确定', '取消'] //可以无限个按钮
        }, function(index, layero){
            $('input[name="cmd"]').val(0)
            $.get('add', 
                   $("#menu_form").serializeArray()
                ,
                function(data) {
                    data.data = data.data+'&#10;'
                    data.data += $('#res_menu_msg').html()
                    $('#res_menu_msg').html(data.data)
                    form.render()
                }
            );
            layer.close(index)
        });
    })
    //==================================生成接口======================//
    //生成模型
    $('.model-add-btn').click(function(){
        layer.confirm('确定生成模型文件吗？？', {
          btn: ['确定', '取消'] //可以无限个按钮
        }, function(index, layero){
            $.get('createModel', 
                   {'model':$('.model-main-table').val()}
                ,
                function(data) {
                   layer.msg(data.msg)
                }
            );
            layer.close(index)
        });
    })
    // 显示添加模型
    form.on('checkbox(show-model)', function(data) {
        if (data.elem.checked) { //判断当前多选框是选中还是取消选中
            $('#model-main-content').show()
        } else {
            $('#model-main-content').hide()
        }
    });
    // 添加参数
    $('.param-add-btn').click(function(){
        $('#param-mian-content').append(
            $('#param-mian-content-tpl').html()
        );
    })
    // 删除参数
    $(document).on('click', '.param-del-btn', function() {
        $(this).parent().remove()
    })
    // 显示接口参数
    form.on('checkbox(show-param)', function(data) {
        if (data.elem.checked) { //判断当前多选框是选中还是取消选中
            $('#param-main-div').show()
        } else {
            $('#param-main-div').hide()
        }
    });
    // 生成接口
    $('.interface-add-btn').click(function(){
        layer.confirm('确定生成接口文件吗？？', {
          btn: ['确定', '取消'] //可以无限个按钮
        }, function(index, layero){
            $.get('createInterface', 
                   {'controller':$('input[name="name_interface"]').val(),
                   'desc':$('input[name="des_interface"]').val()
                }
                ,
                function(data) {
                   layer.msg(data.msg)
                }
            );
            layer.close(index)
        });
    })
    // 显示添加接口
    form.on('checkbox(show-interface)', function(data) {
        if (data.elem.checked) { //判断当前多选框是选中还是取消选中
            $('#interface-main-content').show()
        } else {
            $('#interface-main-content').hide()
        }
    });
    // 显示关联curd
    // 显示关联按钮
    form.on('checkbox(showinterface)', function(data) {
        if (data.elem.checked) { //判断当前多选框是选中还是取消选中
            $('#interface-set').show()
        } else {
            $('#interface-set').hide()
        }
    });

    // 点击追加关联模型
    $('#add-interface-content').click(function() {
        ii++
        // 添加类名
        $('#interface-tpl').find('.field-data').addClass('field-data' + ii)
        $('#interface-tpl').find('.other-table').addClass('other-table' + ii)
        //修改name
        $('#interface-tpl').find('.other-table').prop('name','otable'+ii)
        $('#interface-tpl').find('.other-type').prop('name','otype'+ii)
        $('#interface-tpl').find('.other-key select').prop('name','okey'+ii)
        $('#interface-tpl').find('.main-key select').prop('name','mkey'+ii)
        $('#interface-tpl').find('.fields-div input').prop('name','ofields'+ii)
        $('input[name="inumbers"]').val(ii)
        $('#add-interface-temptl').append(
            $('#interface-tpl').html()
        )

        $("#add-interface-temptl").find(":input").attr("disabled", false);
        $("#add-interface-temptl").find("select").attr("disabled", false);
        var table_name = $('.other-table' + ii).val()
        setFields('.field-data' + ii, table_name)
    })

    // 立即执行
    $('#create_interface').click(function(){
        console.log($("#interface_form").serializeArray())
        layer.confirm('确定执行吗？？', {
          btn: ['确定', '取消'] //可以无限个按钮
        }, function(index, layero){
            $.get('add', 
                   $("#interface_form").serializeArray()
                ,
                function(data) {
                    data.msg = data.msg+'&#10;'
                    data.msg += $('#res_interface_msg').html()
                    $('#res_interface_msg').html(data.msg)
                    form.render()
                }
            );
            layer.close(index)
        });
    })

     // 点击移除
    $(document).on('click', '.interface-del-btn', function() {
        //去除数量
        var n = $('input[name="inumbers"]').val()
        $('input[name="inumbers"]').val(n-1)
        $(this).parent().parent().parent().remove()
    })

    // 点击curd显示对应的文件
    form.on('radio', function(data) {
        let value = data.elem.value
        // 隐藏全部
        $('.curd-hide').hide()
        // 对应的操作显示
        $('#interface_'+value).show()
    });

    var init = {
        table_elem: '#currentTable',
        table_render_id: 'currentTableRenderId',
        index_url: 'addons/command/back/index',
        add_url: 'addons/command/back/add',
    };

    var Controller = {

        index: function() {
            ea.table.render({
                init: init,
                toolbar:['refresh','add'],
                cols: [
                    [
                        { type: 'checkbox' },
                        { field: 'id', title: 'ID' },
                        { field: 'type', title: '类型' },
                        { field: 'params', title: '参数' },
                        { field: 'command', title: '命令' },
                        { field: 'executetime', title: '执行时间(秒)' },
                        { field: 'createtime', title: '创建时间' },
                        { field: 'status', title: '状态' },
                        { width: 250, title: '操作', templet: ea.table.tool,operat:['delete'] },

                    ]
                ],
            });

            ea.listen();
        },
        add: function() {
            iconPickerFa.render({
                elem: '#icon',
                url: PATH_CONFIG.iconLess,
                limit: 12,
                click: function (data) {
                    $('#icon').val('fa ' + data.icon);
                },
                success: function (d) {
                    console.log(d);
                }
            });
            autocomplete.render({
                elem: $('#href')[0],
                url: ea.url('system.menu/getMenuTips'),
                template_val: '{{d.node}}',
                template_txt: '{{d.node}} <span class=\'layui-badge layui-bg-gray\'>{{d.title}}</span>',
                onselect: function (resp) {
                }
            });
            ea.listen();
        },
        
    };
    return Controller;
});